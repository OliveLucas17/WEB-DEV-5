import { useState } from "react"

function Exemplo(){

    // HOOK - useState - manipula o estado da variável
    const[mensagem,setMensagem]=useState("Nenhuma Mensagem do Servidor");
    const[endpointAtual, setEndPointAtual] =useState("");
    const[status,setStatus]=useState("");

    //criando a função busca

    const busca= async(api)=>{
        setEndPointAtual(api);//define o endpoint atual
        setMensagem("Carregando...");//mensagem de carregando
        setStatus("loading..."); //define o status do carregamento
    
        //tratamento de erros
        try{
            //fazendo uma requisição de get no endpoint usando a função fetch
            const resposta = await fetch(`http://localhost:5001${api}`);
            //verifca se a resposa esta ok
            if(!resposta.ok){
                console.log(`Erro na requisição ${resposta.status}`);
            }
            //converte a resposta para texto
            const data =await resposta.text();
            setMensagem(data);//atualiza a mensagem com a resposta do servidor
            setStatus("sucesso");

        }
        catch(error){
            console.log(`erro ao buscar dados ${error}`);
            setMensagem(`Erro ao conectar ao servidor ${error.mensagem}`)
            setStatus("Error")
        }


    }

    return(
        // fragment
        <>
        <div>
            <header>
                <h1>Frontend do Projeto</h1>
                <p>Acessando o servidor Node</p>
            </header>
            <main>
                <div>
                    <button onClick={()=>busca("/teste")}>Acessar Teste</button>
                    <button onClick={()=>busca("/sistema")}>Acessar Sistema</button>
                    <button onClick={()=>busca("/sobre")}>Acessar Sobre</button>
                </div>
                <div>
                    <h2>Rsposta do servidor</h2>
                    <p>Endpoint Atual:<span>{endpointAtual || "Nenhum"}</span></p>
                    <p>{mensagem}</p>
                    <p>Status do Servidor: {status}</p>
                </div>

             </main>
            <footer>
                <p>&copy; 2025</p>
            </footer>
        </div>
        </>
    )
}
export default Exemplo